##### Handy links #####
# https://github.com/Pakillo/R-GIS-tutorial/blob/master/R-GIS_tutorial.md
# https://geoscripting-wur.github.io/IntroToRaster/

#if you don't have the following libraries already installed, install them first:
install.packages(c("sp", "rgdal", "raster"))

##### Libraries #####

library(sp)
library(rgdal)
library(raster)

###### Vector data #####
## Create spatial data from lat and lon info ##
kestrels <- read.csv("idaho_kestrels.csv")
View(kestrels)

#Create spatial data 
kestrel_coords <- data.frame(x=kestrels$B_LON_DECIMAL_DEGREES, y=kestrels$B_LAT_DECIMAL_DEGREES)
kestrels_spatial <- SpatialPoints(coords = kestrel_coords, CRS("+init=epsg:4326")) #code corresponds to WGS84
kestrels_spatial

#Sidenote
EPSG <- rgdal::make_EPSG() #generates a print out of all the coordinate systems 
View(EPSG) 
#projectRaster
#spTransform

#Back to kestrels
kestrels_spatial_df <- SpatialPointsDataFrame(kestrels_spatial, data = kestrels)


###### Rasters #####
## Load raster data - either as raster or brick of raster
temperature <- raster("environment_data/cropT_MAX.tif")
temperature_brick <- brick("environment_data/cropT_MAX.tif")

plot(temperature)
plot(temperature_brick)

## Crop raster
ext <- drawExtent()
cropped_raster <- crop(temperature, ext)
temperature

plot(cropped_raster)

#calculate average temp anomaly in raster
(temp_avg <- cellStats(cropped_raster, stat = "mean"))

# add our kestrel points to cropped raster
points(kestrels_spatial, pch = 20, cex = .5, col = "blue")

#extract temperature data for the points 
point_temp <- extract(cropped_raster, kestrels_spatial)

#saving rasters
#writeRaster

############################################################
##Download precipitation Data
germany <- getData("GADM", country = "DEU", level = 2) #get polygon data of germany
plot(germany)

prec <- getData("worldclim", var = "prec", res=0.5, lon=10, lat=51) #get precipitation data from raster package
plot(prec)

prec_ger1 <- crop(prec, germany) #crop precipitation to extent of germany
spplot(prec_ger1) #plot german precip data

ext <- drawExtent()
cropped_germ <- crop(prec, ext)

prec_ger2 <- mask(prec_ger1, germany) #mask precipitation to shape of germany
spplot(prec_ger2) #plot masked data

(prec_avg <- cellStats(prec_ger2, stat = "mean")) #extract precipitation avg of germany

